<footer class="footer_area">
        
        </div>
        <div class="copy_right">
            © 2020 <a href="#">Blogsia</a>. All rights reserved.
        </div>
    </footer> 