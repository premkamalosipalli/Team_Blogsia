<div class="fixed-sidebar">
 <a href="02-ProfilePage.html" class="logo">
      <div style="background-color:black;">
        <img src="<?php echo base_url("upload/company/".$_SESSION['companylogo'])?>" alt="logo">
      </div>
    </a>
</div>
<header class="header" id="site-header">
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TKGD7NP');</script>
<!-- End Google Tag Manager --> 

  <div class="page-title">
    <h6>Company Profile</h6>
  </div>

  <div class="header-content-wrapper">
    <div class="control-block">
       <div class="author-page author vcard inline-items more">
      </div>

      <div class="author-page author vcard inline-items more">
        <div class="author-thumb">
          <div class="more-dropdown more-with-triangle">
            <div class="mCustomScrollbar" data-mcs-theme="dark">
              <div class="ui-block-title ui-block-title-small">
                <h6 class="title">Your Account</h6>
              </div>
                <ul class="account-settings">
                                  <li>                 
                  <a href="<?php echo site_url('company/ManageProfileC/loadManageProfile');?>">
                    <svg><use xlink:href="#olymp-happy-faces-icon"></use></svg>
                        <span class="left-menu-title">ManageProfile</span>
                  </a>
                </li>
                <li>                 
                  <a href="<?php echo site_url('company/LogoutC');?>">
                    <svg><use xlink:href="#olymp-logout-icon"></use></svg>
                        <span class="left-menu-title">Log Out</span>
                  </a>
                </li>

              </ul>
            </div>
          </div>
        </div>
        <a class="author-name fn">
          <div class="author-content">
            <p class="h6 author-name" style="color:white;"><?php echo $_SESSION['companytitle']?></p>
              
            </div>
        </a>
      </div>
    </div>
  </div>
</header>