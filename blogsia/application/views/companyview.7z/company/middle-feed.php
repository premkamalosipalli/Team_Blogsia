<div id="newsfeed-items-grid col-md-12">

				<div class="ui-block col-md-12">
					<!-- Post -->
					
					<article class="hentry post">
					
							<div class="post__author author vcard inline-items col-md-12">
								<img src="<?php echo base_url('resources/shared/1.jpg');?>" alt="author">
					
								<div class="author-date">
									<p class="h4 author-name" style="color: #FF5E3A;"><?php echo $_SESSION['companyname'];?></p>
								</div>
					
							</div>
					</article>
				</div>	
					<!-- .. end Post -->				
		<div class="ui-block">
		</div>
</div>