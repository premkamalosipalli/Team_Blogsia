<div id="newsfeed-items-grid col-md-12">

				<div class="ui-block col-md-12">
					<!-- Post -->
					
					<article class="hentry post">
					
							<div class="post__author author vcard inline-items col-md-12">
								<img src="<?php echo base_url('resources/shared/'.$_SESSION['profilepic']);?>" alt="author">
					
								<div class="author-date">
									<p class="h4 author-name" style="color: #FF5E3A;"><?php echo $_SESSION['username'];?></p>
									
								</div>
					
								
					
							</div>
					
							
					
						</article>
					
					<!-- .. end Post -->				</div>
				<div class="ui-block">
					
					<!-- Post -->
					
					
					
					<!-- .. end Post -->				</div>
				
				
			</div>

			
			
			</div>