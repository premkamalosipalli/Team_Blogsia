<div class="container">
	<div class="row">
		<div class="col col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="ui-block">
				<div class="top-header">
					<div class="top-header-thumb">
						<img src="<?php echo base_url('resources/shared/'.$_SESSION['profilepic']);?>" alt="nature">
					</div>
					<div class="profile-section">
						<div class="row">
							<div class="col col-lg-5 col-md-5 col-sm-12 col-12">
								
							</div>
							<div class="col col-lg-5 ml-auto col-md-5 col-sm-12 col-12">
								<ul class="profile-menu">
									
									
								</ul>
							</div>
						</div>

						<div class="control-block-button">
							

							
						</div>
					</div>
					<div class="top-header-author">
						<a href="02-ProfilePage.html" class="author-thumb">
							<img src="<?php echo base_url('resources/shared/'.$_SESSION['profilepic']);?>" alt="author" style="height: 85px;">
						</a>
						<div class="author-content">
							<!-- <a href="<?php echo site_url('user/UserC/');?>" class="h4 author-name"><?php echo $_SESSION['username'];?></a> -->
							<p class="h4 author-name"><?php echo $_SESSION['username'];?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
