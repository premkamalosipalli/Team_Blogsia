<script src="<?php echo base_url('resources/user/');?>js/jQuery/jquery-3.4.1.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/jquery.appear.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/jquery.mousewheel.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/perfect-scrollbar.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/jquery.matchHeight.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/svgxuse.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/imagesloaded.pkgd.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/Headroom.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/velocity.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/ScrollMagic.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/jquery.waypoints.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/jquery.countTo.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/popper.min.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/material.min.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/bootstrap-select.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/smooth-scroll.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/selectize.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/swiper.jquery.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/moment.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/daterangepicker.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/fullcalendar.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/isotope.pkgd.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/ajax-pagination.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/Chart.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/chartjs-plugin-deferred.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/circle-progress.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/loader.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/run-chart.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/jquery.magnific-popup.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/jquery.gifplayer.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/mediaelement-and-player.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/mediaelement-playlist-plugin.min.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/sticky-sidebar.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/ion.rangeSlider.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/leaflet.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs/MarkerClusterGroup.js"></script>

<script src="<?php echo base_url('resources/user/');?>js/main.js"></script>
<script src="<?php echo base_url('resources/user/');?>js/libs-init/libs-init.js"></script>
<script defer src="<?php echo base_url('resources/user/');?>fonts/fontawesome-all.js"></script>

<script src="<?php echo base_url('resources/user/');?>Bootstrap/dist/js/bootstrap.bundle.js"></script>

<!-- SVG icons loader -->
<script src="<?php echo base_url('resources/user/');?>js/svg-loader.js"></script>
<script src="<?php echo base_url()?>resources/dropzone/dropzone1/dist/dropzone.js"></script>