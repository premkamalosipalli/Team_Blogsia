<!DOCTYPE html>
<html>

<!-- Mirrored from thememakker.com/templates/swift/university/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Apr 2019 09:37:14 GMT -->
<head>
<title>Blogsia</title>
<?php include_once('topscripts.php');?>
<!-- Dropzone Css -->
<link href="<?php echo base_url("resources/admin/")?>assets/plugins/dropzone/dropzone.css" rel="stylesheet">
<script src="<?php echo base_url("resources/admin/")?>assets/plugins/dropzone/dropzone.js"></script>

</head>

<body class="theme-blush">
<!-- Page Loader -->
<div class="page-loader-wrapper">
    <div class="loader">
        <div class="preloader">
            <div class="spinner-layer pl-blush">
                <div class="circle-clipper left">
                    <div class="circle"></div>
                </div>
                <div class="circle-clipper right">
                    <div class="circle"></div>
                </div>
            </div>
        </div>
        <p>Please wait...</p>
    </div>
</div>
<!-- #END# Page Loader --> 

<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<!-- #END# Overlay For Sidebars --> 
<?php include_once('morphsearch.php');?>


<!-- Top Bar -->
<?php include_once('header.php');?>
<!-- #Top Bar -->

<!--Side menu and right menu -->
<section> 
    <!-- Left Sidebar -->
 <?php include_once('left-bar.php');?>
    <!-- #END# Left Sidebar --> 
    <!-- Right Sidebar -->
 <?php include_once('right-bar.php');?>
    <!-- #END# Right Sidebar --> 
</section>
<!--Side menu and right menu -->

<!-- main content -->
<section class="content home">
    <div class="container-fluid">
        <div class="block-header">
            <h2>Add Admin</h2>
            <small class="text-muted">Welcome to Blogsia</small>
        </div>
        
        <div class="row clearfix top-report">
            
            <div class="col-lg-3 col-sm-6 col-md-6">
                            <form enctype="multipart/form-data" method="post" action="<?php echo site_url("admin/AdminC/addadmin"); ?>" >
                            <div class="form-group">
                                <div class="form-line">
                                    <input type="text" name="uname" class="form-control" placeholder="Username">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-line">
                                    <input type="password" name="password" class="form-control" placeholder="Password">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-line">
                                    <input type="email" name="email" class="form-control" placeholder="Email">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-line">
                                    <input type="text" name="contactNo" class="form-control" placeholder="Contact-No">
                                </div>
                            </div>
                            <div class="form-group">
                                
                                <label> Profile Pic:</label> 
                            
                        </div>
                            <input type="file" name="profilepic" >
                                           
                            <br>
                            <button type="submit" class="btn btn-raised btn-primary m-t-15 waves-effect">Add</button>
                        </form>    
            
            </div>
	   </div>
    </div>
</section>
<!-- main content -->

<div class="color-bg"></div>
<?php include_once('bottomscripts.php');?>
<!-- Jquery Core Js --> 
</body>

<!-- Mirrored from thememakker.com/templates/swift/university/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Apr 2019 09:37:46 GMT -->
</html>

<script type="text/javascript">
    Dropzone.autoDiscover = false;
    var base64 = '';
    $("#myDropzone").dropzone({
        url: "<?= base_url("upload")?>",       
        addRemoveLinks: true,
        maxFiles: 1,
        maxFileSize: 1,
        init: function() {
            this.on("addedfile", function (file) {
                var reader = new FileReader();
                reader.onload = function(event) {
                    // event.target.result contains base64 encoded image                    
                    var base64String = event.target.result;

                    $("#img").val(base64String);
                    handlePictureDropUpload(base64String ,fileName );
                };
                reader.readAsDataURL(file);
            });
        },
    });
</script>