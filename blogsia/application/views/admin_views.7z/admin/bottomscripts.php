<script src="<?php echo base_url("resources/admin/");?>assets/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js -->
<script src="<?php echo base_url("resources/admin/");?>assets/bundles/vendorscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js -->
<script src="<?php echo base_url("resources/admin/");?>assets/bundles/morphingsearchscripts.bundle.js"></script> <!-- Main top morphing search -->

<script src="<?php echo base_url("resources/admin/");?>assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script> <!-- Sparkline Plugin Js -->
<script src="<?php echo base_url("resources/admin/");?>assets/plugins/chartjs/Chart.bundle.min.js"></script> <!-- Chart Plugins Js --> 

<script src="<?php echo base_url("resources/admin/");?>assets/bundles/mainscripts.bundle.js"></script><!-- Custom Js --> 
<script src="<?php echo base_url("resources/admin/");?>assets/js/pages/charts/sparkline.min.js"></script> 
<script src="<?php echo base_url("resources/admin/");?>assets/js/pages/index.js"></script>