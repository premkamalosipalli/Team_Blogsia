

<div id="morphsearch" class="morphsearch">
    <form method="post" class="morphsearch-form">
        <div class="form-group m-0">
            <input type="hidden" value="" class="form-control morphsearch-input"/>
            <button class="morphsearch-submit" type="submit">Search</button>
            <span class="input-group-append search-btn"></span>
        </div>
    </form>
  <!--   Search -->
    <span class="morphsearch-close"></span>
</div>