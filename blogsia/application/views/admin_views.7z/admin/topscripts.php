<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link href="<?php echo base_url("resources/admin/");?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
<!-- Custom Css -->
<link href="<?php echo base_url("resources/admin/");?>assets/css/main.css" rel="stylesheet">

<link href="<?php echo base_url("resources/admin/");?>assets/css/themes/all-themes.css" rel="stylesheet" />
