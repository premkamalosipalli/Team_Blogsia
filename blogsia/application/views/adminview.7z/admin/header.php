<nav class="navbar clearHeader">
    <div class="col-12">
        <div class="navbar-header"> <a href="javascript:void(0);" class="bars"></a> <a class="navbar-brand" href="index.html">Blogsia</a> </div>
<nav class="navbar clearHeader">
    <div class="col-12">
       <nav class="navbar clearHeader">
    <div class="col-12">
        <ul class="nav navbar-nav navbar-right">
                    <li><a href="javascript:void(0);" class="js-right-sidebar" data-close="true"><i class="zmdi zmdi-settings"></i></a></li>
        </ul>
    </div>
</nav>
    </div>
</nav>
    </div>
</nav>