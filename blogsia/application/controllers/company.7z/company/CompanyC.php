<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class CompanyC extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model("company/CompanyM","cm");
	}
	public function index()
	{
		$this->load->view("company/companylogin.php");
	}
	
	public function addCompany()
	{
		
		$data=array(
			"username"=>$this->input->post("txtcname"),
			"password"=>$this->input->post("txtpass"),
			"companytitle"=>$this->input->post("txttitle"),
			"website"=>$this->input->post("txtweb"),
			"logo"=>"",
			"Description"=>$this->input->post("txtdesp")
		);
		$img=$this->input->post('img');
		$image_array_1=explode(";",$img);
		$image_array_2=explode(",",$image_array_1[1]);
		$img1=base64_decode($image_array_2[1]);
		$imagename=$this->input->post('txtcname').".jpg";
		file_put_contents("upload/user/".$imagename,$img1);
		$data['logo']=$imagename;
		
		$this->cm->insertData($data);
		redirect("company/CompanyC");
	} 


	public function checkLogin()
	{
		$data=array(
			"username"=>$this->input->post("txtcname"),
			"password"=>$this->input->post("txtPass")
		);
		$temp=$this->cm->selectData($data);
		if(count($temp)>0)
		 {
		 	$_SESSION['companyid']=$temp[0]->companyid;
		 	$_SESSION['companyname']=$temp[0]->username;
		 	$_SESSION['companytitle']=$temp[0]->companytitle;
		 	$_SESSION['companylogo']=$temp[0]->logo;
		 	$_SESSION['companyemail']=$temp[0]->website;
		 	$_SESSION['companydesp']=$temp[0]->Description;
		 	 redirect("company/OfferC");
		 }else{
		 	$loginerror=array(
		 		"LoginErrMsg"=>"Invalid credentials"
		 	);
		 	//echo $_SESSION['compid']=$temp[0]->companyid;
		 	$this->load->view("company/companylogin",$loginerror);

		 }
	}

}
?>