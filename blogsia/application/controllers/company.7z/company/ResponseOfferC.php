<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ResponseOfferC extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model("company/ResponseOfferM","rom");
	}

	public function index()
	{
		$data=array(
			"respoffer"=>$this->rom->selectResponseOffer()
		);
		 $this->load->view("company/responseoffer",$data);
	}

	public function statusChange($id)
	{
		$this->rom->statusChange($id);
		echo $this->db->last_query();
	 
	}
}
?>