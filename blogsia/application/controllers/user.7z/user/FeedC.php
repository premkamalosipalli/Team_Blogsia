<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FeedC extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model("user/FeedM","fm");
		$this->load->model("user/ArticleM","am");
	}

	public function index()
	{
      $data=array("f.followerid"=>$this->session->userid);
      $temp=array("articles"=>$this->fm->getarticles($data));
      $this->load->view("user/feedview",$temp);    		
	}
	public function changebio()
	{
	   $data=array("bio"=>$this->input->post('txtbio'));
	   $id=array("userid"=>$this->session->userid);
	   $this->fm->chngbio($id,$data);
	   redirect("user/UserC");


	}

	public function checkArticle($aid)
	{
       $data=array(
			"articleid"=>$aid,
			"userid"=>$_SESSION['userid']
		);
		echo $this->fm->chkarticle($data);   
	}
	public function likeArticle($aid)
	{
		$data=array(
			"articleid"=>$aid,
			"userid"=>$_SESSION['userid']
		);
		echo $this->fm->like($data);
	
	}
	public function unlikeArticle($aid)
	{
		$data=array(
			"articleid"=>$aid,
			"userid"=>$_SESSION['userid']
		);
		echo $this->fm->unlike($data);
		
	}

	public function addComments($aid)
	{
		$data=array(
			"articleid"=>$aid,
			"userid"=>$_SESSION['userid'],
			"comment"=>$this->input->post('txtcomment'),
			"createdt"=>date("Y-m-d")
		);

		$this->am->insertComment($data);
		redirect("user/ArticleC/viewArticles/$aid");
	}
	public function checksaveArticle($aid)
	{
       $data=array(
			"articleid"=>$aid,
			"userid"=>$_SESSION['userid']
		);
		echo $this->fm->chksavearticle($data);   
	}
	public function saveArticle($aid)
	{
		$data=array(
			"articleid"=>$aid,
			"userid"=>$_SESSION['userid']
		);
		echo $this->fm->save($data);
	
	}
	public function unsaveArticle($aid)
	{
		$data=array(
			"articleid"=>$aid,
			"userid"=>$_SESSION['userid']
		);
		echo $this->fm->unsave($data);
		
	}
}


?>