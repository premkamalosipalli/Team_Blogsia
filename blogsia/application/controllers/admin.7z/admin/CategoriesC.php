<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CategoriesC extends CI_Controller
{
	function __construct()
	{
		parent:: __construct();
		$this->load->model("admin/CategoriesM","cm");
		if(!isset($_SESSION['aname']))
		{
			redirect("admin/LoginC");
		}
	}
	public function index()
	{
	$data=array("catinfo"=>$this->cm->selectcategories());
        
     $this->load->view("admin/categories",$data);
	}
	// public function loadaddcategory()
	// {
 //        $this->load->view("admin/addcategory");
	// }
	public function addcategory()
	{
		$data=array("categoryname"=>$this->input->post('cat'));
		$this->cm->insertcategory($data);
		redirect("admin/CategoriesC");
	 
	}
	public function removecat($cat)
	{
		$data=array("categoryid"=>$cat);
		$this->cm->deletecat($data);
		redirect('admin/CategoriesC');
	}
	public function loadeditcat($cat)
	{
		$data=array("categoryid"=>$cat);
		$temp=array("catinfo"=>$this->cm->selectbyid($data));
        $this->load->view("admin/editcategory",$temp);    
	}
	public function editcategory($id)
	{
         $data=array("categoryid"=>$id);
         $temp=array("categoryname"=>$this->input->post('cat'));
         $this->cm->updatecat($data,$temp);
         redirect("admin/CategoriesC");
	}

}

?>