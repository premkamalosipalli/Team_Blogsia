<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class LogoutC extends CI_Controller
{
	
	function __construct()
	{
	parent ::__construct();
	if(!isset($_SESSION['aname']))
	{
		redirect("admin/LoginC");
	}
	}

	public function index()
	{
		session_destroy();
		redirect("admin/LoginC");
	}
}
?>