<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminC extends CI_Controller
{ 
    public function __construct()
	{
		parent:: __construct();
		$this->load->model("admin/AdminM","am");
		if(!isset($_SESSION['aname']))
		{
			redirect("admin/LoginC");
		}
	}
	
	public function index()
	{
      $data=array("admin"=>$this->am->getadmin());
      $this->load->view("admin/alladmin",$data);         
	}

	public function loadaddadmin()
	{
		$this->load->view("admin/addadmin");
	}
	public function addadmin()
	{
		$img=$_FILES['profilepic']['name'];
		copy($_FILES['profilepic']['tmp_name'],"C:/xampp/htdocs/blogsia/resources/admin/".$img);
		$data=array("username"=>$this->input->post('uname'),
        "password"=>$this->input->post('password'),
        "emailid"=>$this->input->post('email'),
        "contactNo"=>$this->input->post('contactNo'),
        "profilepic"=>$img  
		);
		$this->am->insertadmin($data);
		redirect("admin/AdminC");
       
	}
	public function editprofile()
	{
		$id=array("adminid"=>$_SESSION['aid']);
		
		$data=array("ainfo"=>$this->am->fetchadmin($id));
		$this->load->view("admin/editprofile",$data);
	}
	public function updateprofile()
	{

		if(!empty($_FILES['pic']['name']))
		{
		$img=$_FILES['pic']['name'];
		copy($_FILES['pic']['tmp_name'],"C:/xampp/htdocs/blogsia/resources/admin/".$img);
		$data=array("username"=>$this->input->post('username'),
        "emailid"=>$this->input->post('email'),
        "contactNo"=>$this->input->post('cn'),
        "profilepic"=>$img  
		);
	    }
	    else
	    {
		$data=array("username"=>$this->input->post('username'),
        "emailid"=>$this->input->post('email'),
        "contactNo"=>$this->input->post('cn'), 
		);
	    }
	    $id=array("adminid"=>$_SESSION['aid']);
	    //print_r($data);
	    $this->am->updateadmin($id,$data);
	    redirect("admin/AdminC");
	}

}

?>