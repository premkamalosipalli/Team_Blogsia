<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginC extends CI_Controller
{
   public function __construct()
	{
	   parent::__construct();
	   $this->load->model("admin/LoginM","lm");
	}
	public function index()
	{
		$this->load->view("admin/login.php");
	}

	public function checkuser()
	{
		$data=array("username"=>$this->input->post('uname'),
        "password"=>$this->input->post('pass')
	);
		$temp=$this->lm->getuser($data);
		if(count($temp)>0)
		{    
			 $_SESSION['aid']=$temp[0]->adminid;
             $_SESSION['aname']=$temp[0]->username;
             $_SESSION['pic']=$temp[0]->profilepic;
              
             redirect("admin/CategoriesC");
		}
		else
		{
			$error=array("errormsg"=>"Invalid credentials");
			$this->load->view("admin/login.php",$error);
		}
	}


}

?>