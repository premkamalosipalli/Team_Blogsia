<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RegM extends CI_Model
{
	public function insertUser($data)
	{
		return $this->db->insert('tbluser',$data);
	}

	
	public function selectCityByState($data)
	{
		return $this->db->where($data)->get('tblcity')->result();
	}

}

?>