<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class TrendingM extends CI_Model
{
	public function showTop10()
	{
		return $this->db->select("COUNT(l.likeid) as totallikes ,COUNT(c.commentid) as totcom,a.articletitle,a.description,a.articleid,a.featuredimage as fimg,a.createdt,u.username ,u.profilepic as uimg")->from("tbllike l")->join("tbluser u","l.userid=u.userid")->join("tblarticle a","l.articleid=a.articleid")->join("tblcomment c","c.articleid=a.articleid","left outer")->order_by("a.articleid")->group_by("a.articleid")->limit(10)->get()->result();
	}

	public function articleTotalLikes($data)
	{
		return $this->db->from("tbllike")->count_all_results();
	}

	public function articleTotalComments($data)
	{
		return $this->db->from("tblcomment")->count_all_results();
	}

	public function articledetails($data)
	{
		 return $this->db->select("COUNT(l.likeid) as totallikes ,COUNT(c.commentid) as totcom,a.*,u.username ,u.profilepic as uimg")->from("tblarticle a")->join("tbluser u","a.userid=u.userid")->join("tbllike l","l.articleid=a.articleid","left outer")->join("tblcomment c","c.articleid=a.articleid","left outer")->where($data)->group_by("a.articleid")->get()->result();
	  
	}
}

?>