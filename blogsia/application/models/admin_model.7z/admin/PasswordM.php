<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PasswordM extends CI_Model
{
	// public function getdata($data)
	// {
	// 	$this->db->where($data);
	// 	return $this->db->get('tbladmin')->num_rows();
	// }

	public function getpass($data)
	{
        $this->db->select("password");
        $this->db->from('tbladmin');
        $this->db->where($data);
        return $this->db->get()->result();
	}
}

?>