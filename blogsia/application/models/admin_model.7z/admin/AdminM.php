<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminM extends CI_Model
{
     public function getadmin()
     {
       return $this->db->get("tbladmin")->result();      
     }
     public function insertadmin($data)
     {
     	return $this->db->insert("tbladmin",$data);
     }
     public function fetchadmin($id)
     {
        return $this->db->where($id)->get('tbladmin')->result();
     }

     public function updateadmin($id,$data)
     {
     	return $this->db->where($id)->update('tbladmin',$data);
     }
}

?>