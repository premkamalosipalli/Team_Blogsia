<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class CompanyM extends CI_Model
{
	public function insertData($data)
	{
		return $this->db->insert("tblcompany",$data);
	}

	public function selectData($data)
	{
		return $this->db->where($data)->get("tblcompany")->result();
	}

}

?>